
let handler = async (m, { conn }) => {

m.reply(`
≡  *𝐊𝐢𝐧𝐠 𝐒𝐡𝐞𝐥𝐛𝐲ᴮᴼᵀ ┃ SUPPORT*

◈ ━━━━━━━━━━━━━━━━━━━━ ◈
▢ Grupo *1*
https://chat.whatsapp.com/KkkqjVeMK1q6lnTFiMb5eK


◈ ━━━━━━━━━━━━━━━━━━━━ ◈
▢ *Telegram*
• https://t.me/MR_X61

▢ *instagram*
• https://instagram.com/rnj_.6?igshid=MzNlNGNkZWQ4Mg==

▢ *YouTube*
• https://www.youtube.com/@Scudia-`)

}
handler.help = ['support']
handler.tags = ['main']
handler.command = ['grupos', 'groupdylux', 'dxgp', 'dygp', 'gpdylux', 'support', 'جروب', 'دعم', 'جروب كينج شيلبي'] 

export default handler
