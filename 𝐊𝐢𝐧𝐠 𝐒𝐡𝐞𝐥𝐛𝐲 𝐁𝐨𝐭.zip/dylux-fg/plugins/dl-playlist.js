
import { youtubeSearch } from '@bochilteam/scraper'
import yts from 'yt-search'
let handler = async(m, { conn, usedPrefix, text, args, command }) => {

    if (!text) throw `✳️ Ingresa el título de una canción\n\n*📌 Ejemplo*\n*${usedPrefix + command}* Lil Peep hate my fuccn life `
    m.react('📀')
    let result = await yts(text)
    let ytres = result.videos
    let listSections = []
	Object.values(ytres).map((v, index) => {
	listSections.push([`${index}┃ ${v.title}`, [
          ['🎶 MP3', `${usedPrefix}fgmp3 ${v.url}`, `▢ ⌚ *المدة:* ${v.timestamp}\n▢ 👀 *المشاهدات:* ${v.views}\n▢ 📌 *العنوان* : ${v.title}\n▢ 📆 *تم التحميل:* ${v.ago}\n`],
          ['🎥 MP4', `${usedPrefix}fgmp4 ${v.url}`, `▢ ⌚ *المدة:* ${v.timestamp}\n▢ 👀 *المشاهدات:* ${v.views}\n▢ 📌 *العنوان* : ${v.title}\n▢ 📆 *تم التحميل:* ${v.ago}\n`]
        ]])
	})
	return conn.sendList(m.chat, '  ≡ *𝐊𝐢𝐧𝐠 𝐒𝐡𝐞𝐥𝐛𝐲┃ᴮᴼᵀ  *🔎', `\n 📀 Aqui una lista de resultados de :\n *${text}*`, fgig, `Click Aquí `, listSections, m)
}
handler.help = ['play2']
handler.tags = ['dl']
handler.command = ['play2', 'playvid2', 'playlist', 'playlista', '2تشغيل'] 
handler.disabled = true

export default handler
